package edu.cau.cps.cis301.asazegar;

import java.io.PrintWriter;

/**
 * The main class for the CS410J appointment book Project
 */
public class Project2 {

  private static PrintWriter out = new PrintWriter(System.out,true);
  protected static void usage(){
    out.println("\nusage: java edu.cau.cps.cis301.asazegar.Project2 [options] <args>");
    out.println("   args are (in this order):");
    out.println("\towner\t\t\tThe person whose owns the appt book");
    out.println("\tdescription\t\tA description of the appointment");
    out.println("\tbeginTime\t\tWhen the appt begins (24-hour time)       ");
    out.println("\tendTime\t\t\tWhen the appt ends (24-hour time)");
    out.println("options are (options may appear in any order): ");
    out.println("\t-print\t\t\tPrints a description of the new appointment        ");
    out.println("\t-README\t\t\tPrints a README for this project and exits Date and       ");
    out.println("\t\t\t\t\ttime should be in the format: mm/dd/yyyy hh:mm");
    System.exit(1);
  }

  protected static Appointment parseArgs(String[] args){
    boolean isPrintSet=false;
    Appointment appointment = new Appointment();

    String owner = null;
    String description=null;
    String startDate=null;
    String startTime=null;
    String endDate=null;
    String endTime=null;

    for (int i=0;i< args.length;i++){
      if(args[i].equals("-README")){
        usage();
      }else if(args[i].equals("-print")){
        isPrintSet = true;
        if(i!=0){
          usage();
        }
      }

      if(isPrintSet && i==1){
        owner = args[i];
      }else if(!isPrintSet && i==0){
        owner = args[i];
      }


    }


    return appointment;
  }
  public static void main(String[] args) {
    Appointment appointment;// Refer to one of Dave's classes so that we can be sure it is on the classpath
    //System.err.println("Missing command line arguments");
    if(args==null || args.length==0){
      usage();
    }

    appointment = parseArgs(args);



    System.exit(1);
  }

}