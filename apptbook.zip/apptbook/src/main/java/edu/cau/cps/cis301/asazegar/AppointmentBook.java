package edu.cau.cps.cis301.asazegar;

import edu.pdx.cs410J.AbstractAppointment;
import edu.pdx.cs410J.AbstractAppointmentBook;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

public class AppointmentBook extends AbstractAppointmentBook<Appointment> {
    private List<Appointment> appointmentList;

    public AppointmentBook(){
        appointmentList = new LinkedList<Appointment>();

    }

     @Override
    public String getOwnerName() {
        return null;
    }

    @Override
    public Collection getAppointments() {
        return appointmentList;
    }

    @Override
    public void addAppointment(Appointment Appointment) {

    }

}
