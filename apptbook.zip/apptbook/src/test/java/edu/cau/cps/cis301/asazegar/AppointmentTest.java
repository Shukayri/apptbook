package edu.cau.cps.cis301.asazegar;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;

/**
 * Unit tests for the {@link Appointment} class.
 */
public class AppointmentTest {

  private  Appointment appointment;
  private  String[] args;
  @Before
  public void setup(){
    appointment = new Appointment();
    String testArgs = "-print,\"Pares Williams\",-README,\"Meeting with Dr. George\",9/18/2019,13:1,09/18/2019,14:05";
    args = testArgs.split(",");
  }
  @Test(expected = UnsupportedOperationException.class)
  public void getBeginTimeStringNeedsToBeImplemented() {
    appointment.getBeginTimeString();
  }

  @Test
  public void initiallyAllAppointmentsHaveTheSameDescription() {
    Appointment appointment = new Appointment();
    assertThat(appointment.getDescription(), containsString("not implemented"));
  }

  @Test
  public void forProject1ItIsOkayIfGetBeginTimeReturnsNull() {
    Appointment appointment = new Appointment();
    assertThat(appointment.getBeginTime(), is(nullValue()));
  }

  @Test
  public void forREADMEoption(){
    Project2.parseArgs(args);
  }
}
